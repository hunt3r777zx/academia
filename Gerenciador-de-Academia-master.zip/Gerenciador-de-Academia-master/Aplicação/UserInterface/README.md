# Gestor-de-Academia
Este projeto contém uma solução para auxiliar profissionais autônomos na rotina de gerenciamento de academias de musculação. Fornecendo ferramentas para cadastro de alunos, medidas musculares, peso e entre outras coisas. Também, auxilia o gestor na tomada de decições de negócio a partir da análise gráfica de informações sobre faturamento, quantidade de alunos, contas a receber, etc.

## Ambiente
O projeto consiste em uma aplicação C# Desktop Windows Forms com uma interface totalmente intuitiva ao gestor.

### Atualizações
Este não é o projeto final, é uma versão de apresentação desenvolvida para um cliente.
