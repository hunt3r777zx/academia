﻿using System;


public class Conexão
{
	public Conexão()
	{

	}
}
